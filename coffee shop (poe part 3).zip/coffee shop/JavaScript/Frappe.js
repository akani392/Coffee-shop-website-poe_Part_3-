// Store user's drink selections (internally, not shown)
const selections = {
  size: null,
  milk: null,
  blend: null,
  toppings: []
};

window.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".menu-buttons").forEach(group => {
    group.addEventListener("click", e => {
      if (e.target.tagName !== "BUTTON") return;

      const category = getCategoryFromElement(e.target);

      if (category === "toppings") {
        // Allow multiple toppings
        e.target.classList.toggle("selected");
        const value = e.target.textContent.trim();

        if (selections.toppings.includes(value)) {
          selections.toppings = selections.toppings.filter(t => t !== value);
        } else {
          selections.toppings.push(value);
        }
      } else {
        // Only one choice per category
        group.querySelectorAll("button").forEach(btn => btn.classList.remove("selected"));
        e.target.classList.add("selected");
        selections[category] = e.target.textContent.trim();
      }

      console.log("Selections:", selections);
    });
  });
});

// Helper function to find which section the button belongs to
function getCategoryFromElement(element) {
  const prevHeading = element.closest("div").previousElementSibling.textContent.toLowerCase();
  if (prevHeading.includes("size")) return "size";
  if (prevHeading.includes("milk")) return "milk";
  if (prevHeading.includes("blend")) return "blend";
  if (prevHeading.includes("topping")) return "toppings";
}
 