(function(){
    // EmailJS initialization 
    emailjs.init("fU12iYWyRcVlEOfve"); 
})();

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("LatteClubSignup");

    if (!form) return; 

    form.addEventListener("submit", (event) => {
        event.preventDefault(); 
 
        //  DATA COLLECTION
        const name = document.getElementById("first-name").value;
        const surname = document.getElementById("surname").value;
        const email = document.getElementById("email").value;
        const birthday = document.getElementById("birthday").value;
        const store = document.getElementById("store").value;

        let preferences = [];
        if (document.getElementById("newsletter").checked) preferences.push("Email Newsletter");
        if (document.getElementById("sms").checked) preferences.push("SMS Notifications");

        // BIRTHDAY CHECK
        const today = new Date();
        const userBirthday = new Date(birthday);

        const isBirthday =
            today.getDate() === userBirthday.getDate() &&
            today.getMonth() === userBirthday.getMonth();

        //  BUILD AND DISPLAY CUSTOM SUMMARY
        const summaryText = `
            <strong>Name:</strong> ${name}<br>
            <strong>Surname:</strong> ${surname}<br>
            <strong>Email:</strong> ${email}<br>
            <strong>Birthday:</strong> ${birthday}<br>
            <strong>Preferences:</strong> ${preferences.join(", ")}<br>
            <strong>Nearest Store:</strong> ${store}
        `;

        document.getElementById("summaryText").innerHTML = summaryText;

        if (isBirthday) {
            document.getElementById("birthdayMessage").style.display = "block";
        } else {
            document.getElementById("birthdayMessage").style.display = "none";
        }
        
        // UI TRANSITION
        
        // Hide the form
        form.style.display = "none";
        
        // Show the custom summary screen
        document.getElementById("summary").style.display = "block";
        
        // Reset form fields after showing the summary
        form.reset(); 

    });
    
    // THE BACK BUTTON LISTENER
    document.getElementById("backToForm").addEventListener("click", () => {
        // Hide summary
        document.getElementById("summary").style.display = "none";

        // Show the form again without clearing it
        document.getElementById("LatteClubSignup").style.display = "block";
    });
});

// EMAIL JS
document.getElementById("emailRegisterBtn").addEventListener("click", function(event) {
    event.preventDefault();  // STOP form from clearing or submitting

    const params = {
        first_name: document.getElementById("first-name").value,
        last_name: document.getElementById("surname").value,
        email_address: document.getElementById("email").value,
        to_email: document.getElementById("email").value,
        date_of_birth: document.getElementById("birthday").value,
        store_location: document.getElementById("store").value
    };

    emailjs.send("service_mena621", "template_2igacyr", params)
        .then(function() {
            alert("Registration email sent successfully!");
        })
        .catch(function(error) {
            alert("Email failed.\n" + JSON.stringify(error));
        });
});

