// Function to display and update date & time
function updateDateTime() {
  const now = new Date();

  // Format for South Africa (ZA)
  const options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };

  // Update the footer div
  const footerDateTime = document.getElementById('footerDateTime');
  if (footerDateTime) {
    footerDateTime.textContent = now.toLocaleDateString('en-ZA', options);
  }
}

// Run once and then update every second
updateDateTime();
setInterval(updateDateTime, 1000);
