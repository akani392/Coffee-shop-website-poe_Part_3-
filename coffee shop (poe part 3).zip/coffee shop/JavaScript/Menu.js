function showMainSection(section) {
	
	const drinksSection = document.getElementById("drinksSection");
	const foodSection = document.getElementById("foodSection");
	const drinksFilter = document.getElementById("drinksFilter");
	const foodFilter = document.getElementById("foodFilter"); // Get the food filter element

	if (!drinksSection || !foodSection) return; // Safety check

	switch (section) {
		case "drinks":
			drinksSection.style.display = "block";
			foodSection.style.display = "none";
			
            // SHOW the Drinks filter
			if (drinksFilter) {
				drinksFilter.style.display = "block";
				filterDrinks("all"); // Reset filter to show all drinks
			}
            // HIDE the Food filter
            if (foodFilter) foodFilter.style.display = "none";
			break;

		case "food":
			drinksSection.style.display = "none";
			foodSection.style.display = "block";
			
            // HIDE the Drinks filter
			if (drinksFilter) drinksFilter.style.display = "none";
            // SHOW the Food filter
            if (foodFilter) {
                foodFilter.style.display = "block";
                filterFood("all"); // Reset filter to show all food
            }
			break;

		default: // "all"
			drinksSection.style.display = "block";
			foodSection.style.display = "block";
			
            // HIDE BOTH filters
			if (drinksFilter) drinksFilter.style.display = "none";
            if (foodFilter) foodFilter.style.display = "none";
			break;
	}
}

// Function to filter drinks by type (Ensure your filterFood function is also fixed)
function filterDrinks(type) {
	const drinkItems = document.querySelectorAll("#drinksSection .image-item");
	if (drinkItems.length === 0) return;
	drinkItems.forEach(item => {
		item.style.display = (type === "all" || item.classList.contains(type)) ? "block" : "none";
	});
}

// Fixed filterFood function (uses '=' for assignment)
function filterFood (type){
	const foodItems = document.querySelectorAll("#foodSection .image-item");
    const normalizedType = type.toLowerCase();
    
	if (foodItems.length === 0) return;
	
	foodItems.forEach(item => {
		item.style.display = (normalizedType === "all" || item.classList.contains(normalizedType))? "block" : "none";
	});
}


// Show all sections on page load (this triggers the 'default' case, hiding filters)
window.addEventListener("DOMContentLoaded", () => showMainSection("all"));