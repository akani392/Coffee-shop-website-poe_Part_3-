function changeMap (locationKey){
	// Fix 1: Ensure mapFrame is correctly retrieved (no extra parenthesis)
	const mapFrame = document.getElementById('mapFrame'); 
	const placeholder = document.getElementById('mapPlaceholder');
	
	// holding all map urls for each Location
	const mapUrls = {
		 // Ensure these URLs are your actual Google Map embed links
		 "Bassonia": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3400.469484945368!2d28.065480675201453!3d-26.278527777030774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950f0072e5a491%3A0x83636e335f085faa!2sBassonia%20Shopping%20Centre!5e1!3m2!1sen!2sza!4v1755874800447!5m2!1sen!2sza",
		 "Bedfordview": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3403.3362101789758!2d28.1358953!3d-26.180533000000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e95118b56497de7%3A0xc4e44b491d4aeea3!2sBedford%20Village%20Shopping%20Centre!5e1!3m2!1sen!2sza!4v1763044780758!5m2!1sen!2sza",
		 "Sandton":"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d6811.107873016891!2d28.054298599999996!3d-26.1044888!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1ssandton%20mall!5e1!3m2!1sen!2sza!4v1763045013051!5m2!1sen!2sza",
		 "Rosebank": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3404.355716919115!2d28.043655899999997!3d-26.145600400000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950cf295ac8623%3A0x2e79056da5431600!2sThe%20Zone%20%40%20Rosebank!5e1!3m2!1sen!2sza!4v1763045111014!5m2!1sen!2sza",
		 // Ensure this key matches the HTML value exactly
		 "Morningside": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3406.1915167253546!2d28.060058899999998!3d-26.082588499999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e95731eb6e4e3ab%3A0x6a52bd98aed2fe7b!2sMorningside%20Shopping%20Centre!5e1!3m2!1sen!2sza!4v1763045202078!5m2!1sen!2sza" 
	};
	
	// get url based on user choice
	const newUrl = mapUrls[locationKey];
	
	if (newUrl) {
		
		
		placeholder.style.display = 'none';
		mapFrame.style.display = 'block';
		
		mapFrame.src = newUrl;
	} else {
        // If the user selects the disabled/empty option 
        placeholder.style.display = 'block';
        mapFrame.style.display = 'none';
        mapFrame.src = ""; 
    }
}

// Ensure the map frame is initially hidden and the placeholder is visible
document.addEventListener("DOMContentLoaded", () => {
    const mapFrame = document.getElementById('mapFrame');
    const placeholder = document.getElementById('mapPlaceholder');
    const selector = document.getElementById('locationSelector');
    
    // Initial Setup: If no location is selected (the default case)
    if (selector.value === "" || selector.value === null) {
        mapFrame.style.display = 'none';
        placeholder.style.display = 'block'; // Ensure placeholder is visible
    } 
    // If a default location was somehow loaded 
    else {
        changeMap(selector.value);
    }
});

// Gallery Lightbox Functions

// Array of all image objects
const galleryImages = [
    { src: 'images/23.jpg', caption: 'Bassonia Shopping Centre' },
    { src: 'images/24.jpg', caption: 'Bedfordview Square' },
    { src: 'images/25.jpg', caption: 'Sandton City Mall' },
    { src: 'images/26.jpg', caption: 'Morningside' },
    { src: 'images/27.jpg', caption: 'Up coming Store' }
];
let slideIndex = 0; // Tracks the currently displayed image


function showSlides(n) {
    if (n >= galleryImages.length) { 
        slideIndex = 0; 
    } else if (n < 0) {
        slideIndex = galleryImages.length - 1; 
    } else {
        slideIndex = n;
    }
    
    const currentImage = galleryImages[slideIndex];
    document.getElementById('lightbox-img').src = currentImage.src;
    document.getElementById('lightbox-caption').innerHTML = currentImage.caption;
}

// Function to change the slide 
function plusSlides(n) {
    showSlides(slideIndex + n);
}

//Function to open the lightbox when a thumbnail is clicked
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.gallery-item').forEach(item => {
        item.addEventListener('click', (e) => {
            
            const index = parseInt(item.getAttribute('data-index'));
            document.getElementById('lightbox').style.display = 'block';
            showSlides(index);
        });
    });
});

//  close the lightbox
function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
}